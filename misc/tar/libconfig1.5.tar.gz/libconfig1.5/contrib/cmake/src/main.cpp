#include <iostream>
#include <fstream>
#include <libconfig.h++>

using namespace std;
using namespace libconfig;

int main ( int argc, char **argv )
{
    Config cfg;
    
    return (0);
}