#ifndef CPU_H

int set_cpu(int cpu_id);
int set_thread_cpu(int cpu_id);

#endif
