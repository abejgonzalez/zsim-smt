#include "../benchmark.h"

int main() {
	dcache_good(0);
}
