#include "../benchmark.h"

int main() {
	branch_miss(0);
}
