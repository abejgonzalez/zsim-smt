#include "../benchmark.h"

int main() {
	dcache_miss(0);
}
