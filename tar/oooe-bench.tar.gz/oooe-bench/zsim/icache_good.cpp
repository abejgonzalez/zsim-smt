#include "../benchmark.h"

int main() {
	icache_good(0);
}
