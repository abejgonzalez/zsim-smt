#include "../benchmark.h"

int main() {
	branch_good(0);
}
