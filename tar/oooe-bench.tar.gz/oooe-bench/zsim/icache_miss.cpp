#include "../benchmark.h"

int main() {
	icache_miss(0);
}
